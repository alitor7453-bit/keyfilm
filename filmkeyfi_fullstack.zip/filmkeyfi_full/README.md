# FİLMKEYFİ — Tam Full Stack Proje

Bu paket; kullanıcı sitesi, gerçek sunucu tarafı giriş/kayıt, admin paneli, film yönetimi, MP4 yükleme/oynatma, odalar, bildirimler ve Shopier ödeme yapılandırmasını içerir.

## Gereksinim
- Node.js 20+ önerilir
- Bir VPS/Render/Railway/Fly.io/benzeri Node sunucusu
- HTTPS (canlı ortamda)

## Kurulum
1. `npm install`
2. `.env.example` dosyasını `.env` olarak kopyala.
3. `JWT_SECRET` değerini uzun rastgele bir değer yap.
4. `ADMIN_EMAIL` ve `ADMIN_PASSWORD` belirle.
5. `npm start`
6. Site: `http://SUNUCU:3000`
7. Admin: `http://SUNUCU:3000/admin`

İlk açılışta `data.json` otomatik oluşur.

## Admin
Film ekleme/düzenleme/silme, poster ve MP4 yükleme, kullanıcı onayı, kategori yönetimi, oda yönetimi, bildirim, rapor ve Shopier ayarları vardır.

MP4 dosyaları admin panelinden yüklenebilir. Sunucu URL'si `/uploads/videos/...` olarak kaydedilir ve HTML5 `<video controls>` ile oynatılır.

## Shopier
Shopier güncel olarak API ve webhook altyapısı sunuyor. Shopier resmi yardım merkezinde API'nin REST mimarisiyle çalıştığı ve kişisel erişim anahtarlarının hesap erişimi için kullanılabildiği belirtiliyor. OSB ise eski nesil yöntem; güncel alternatif olarak webhook öneriliyor.

Bu proje, ödeme kaydı + Shopier checkout linki + webhook endpointini hazırlar. Shopier hesabındaki güncel API/webhook kimlik doğrulama yöntemi, hesabınıza verilen erişim bilgileri ve ürün/ödeme akışına göre `.env` ve admin ayarlarıyla tamamlanmalıdır. Shopier'in gizli anahtarlarını frontend/GitHub'a koymayın.

Webhook URL:
`https://SENIN-DOMAININ/api/payments/shopier/webhook`

## GitHub Pages notu
GitHub Pages sadece statik dosyaları sunar; bu projenin gerçek giriş/kayıt, MP4 upload, admin ve ödeme webhookları için Node backend'i çalıştıran bir sunucu gerekir. Frontend'i Pages'te tutmak istiyorsanız API URL'sini ayrı backend domainine göre değiştirmeniz gerekir.

## Varsayılan admin
`.env` içinde değiştirilmelidir. Örnek:
- admin@filmkeyfi.local
- ChangeMe123!

Canlıya almadan önce mutlaka değiştir.
